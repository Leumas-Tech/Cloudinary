// Cloudinary/controllers.js
const axios = require('axios'); // F
const cloudinary = require('./config');
const multer = require('multer');
// const cloudinary = require('cloudinary').v2;
const { Readable } = require('stream');

const upload = multer({ dest: 'uploads/' });

const uploadImageToCloudinary = upload.single('image');

exports.postUploadImageToCloudinary = (req, res) => {
  if (!req.files || Object.keys(req.files).length === 0) {
    return res.status(400).send('No files were uploaded.');
  }

  // 'image' is the name of the input field in the form
  let imageFile = req.files.image;

  // Use the mv() method to place the file somewhere on your server
  imageFile.mv('uploads/' + imageFile.name, function(err) {
    if (err)
      return res.status(500).send(err);

    cloudinary.uploader.upload('uploads/' + imageFile.name, (error, result) => {
      if (error) {
        console.error('Cloudinary Error:', error);
        return res.status(500).send('Failed to upload image');
      }
      res.json({ success: true, imageUrl: result.url });
    });
  });
};

exports.uploadImage = async (req, res) => {
  // Check if the request has files (for file upload)
  if (req.file) {
    const image = req.file;

    cloudinary.uploader.upload(image.path, (error, result) => {
        if (error) {
            return res.status(500).send('Failed to upload image');
        }
        res.json({
            success: true,
            imageUrl: result.url
        });
    });
  } 
  // Check if imageUrl is provided in the request body (for URL upload)
  else if (req.body.imageUrl) {
    const imageUrl = req.body.imageUrl;

    cloudinary.uploader.upload(imageUrl, (error, result) => {
      if (error) {
        return res.status(500).send('Failed to upload image from URL');
      }
      res.json({
        success: true,
        imageUrl: result.url
      });
    });
  } 
  // If neither files nor imageUrl are provided
  else {
    return res.status(400).send('No image provided.');
  }
}

exports.uploadBuffer = async (req, res) => {
  if (!req.file) {
    return res.status(400).send('No image file uploaded.');
  }

  const imageBuffer = req.file.buffer;

  // Upload to Cloudinary
  cloudinary.uploader.upload_stream({ resource_type: 'image' }, (error, result) => {
      if (error) {
          console.error('Error uploading to Cloudinary:', error);
          return res.status(500).send('Error uploading image to Cloudinary');
      }

      res.json({ cloudinaryUrl: result.url });
  }).end(imageBuffer);
};


exports.listImages = async (req, res) => {
  cloudinary.search
    .expression('resource_type:image')
    .sort_by('public_id','desc')
    .max_results(30) // This can be paginated.
    .execute().then(result => res.json(result));
};

exports.deleteImage = async (req, res) => {
  const { publicId } = req.params;

  cloudinary.uploader.destroy(publicId, (error, result) => {
    if (error) {
      return res.status(500).send('Failed to delete image');
    }
    res.json({
      success: true,
      message: 'Image deleted successfully'
    });
  });
};

exports.updateImage = async (req, res) => {
  if (!req.files || Object.keys(req.files).length === 0) {
    return res.status(400).send('No files were uploaded.');
  }

  const image = req.files.image;
  const { publicId } = req.params;

  cloudinary.uploader.upload(image.tempFilePath, { public_id: publicId, overwrite: true }, (error, result) => {
    if (error) {
      return res.status(500).send('Failed to update image');
    }
    res.json({
      success: true,
      imageUrl: result.url
    });
  });
};



// For sending to different cloud

exports.uploadToDifferentCloud = async (req, res) => {
  const { cloudName, apiKey, apiSecret } = req.body;
  
  if (!req.files || Object.keys(req.files).length === 0) {
    return res.status(400).send('No files were uploaded.');
  }

  if (!cloudName || !apiKey || !apiSecret) {
    return res.status(400).send('Incomplete Cloudinary configuration.');
  }

  const image = req.files.image;

  const customCloudinary = require('cloudinary').v2;
  customCloudinary.config({
    cloud_name: cloudName,
    api_key: apiKey,
    api_secret: apiSecret,
  });

  customCloudinary.uploader.upload(image.tempFilePath, (error, result) => {
    if (error) {
      return res.status(500).send('Failed to upload image to the custom cloud.');
    }
    res.json({
      success: true,
      imageUrl: result.url
    });
  });
};

exports.resizeImage = async (req, res) => {
  if (!req.files || Object.keys(req.files).length === 0) {
    return res.status(400).send('No files were uploaded.');
  }

  const width = parseInt(req.body.width);
  const height = parseInt(req.body.height);

  if (!width || !height) {
    return res.status(400).send('Width and height are required.');
  }

  const imageUrl = cloudinary.url(req.files.image.name, { width: width, height: height, crop: "fill" });
  res.json({
    success: true,
    resizedImageUrl: imageUrl
  });
};

exports.forwardImageToEndpoint = async (req, res) => {
  const endpoint = req.body.endpoint;

  if (!endpoint) {
    return res.status(400).send('Endpoint is required.');
  }

  if (!req.files || Object.keys(req.files).length === 0) {
    return res.status(400).send('No files were uploaded.');
  }

  const image = req.files.image;

  axios.post(endpoint, {
    image: image.data
  }).then(response => {
    res.json({
      success: true,
      message: 'Image forwarded successfully',
      endpointResponse: response.data
    });
  }).catch(error => {
    return res.status(500).send('Failed to forward the image.');
  });
};

exports.analyzeImage = async (req, res) => {
    if (!req.files || Object.keys(req.files).length === 0) {
      return res.status(400).send('No files were uploaded.');
    }
  
    const image = req.files.image;
  
    cloudinary.uploader.upload(image.tempFilePath, {
      eager: [{width: 200, height: 200, crop: "pad", audio_codec: "none"}],
      eager_async: true,
      eager_notification_url: "https://mysite.example.com/notify_endpoint",
      colors: true, 
      detection: "adv_face"
    }, (error, result) => {
      if (error) {
        return res.status(500).send('Failed to analyze the image.');
      }
      res.json({
        success: true,
        analysis: {
          dominantColors: result.colors,
          facesDetected: result.info.detection.adv_face.data
        }
      });
    });
  };
  
















  // Bulk

  exports.bulkUpload = async (req, res) => {
    if (!req.files) {
      return res.status(400).send('No files were uploaded.');
    }
  
    const images = req.files.images;  // Assuming 'images' field contains an array of files
  
    const uploadPromises = images.map(image => 
      new Promise((resolve) => {
        setTimeout(() => {
          cloudinary.uploader.upload(image.tempFilePath, (error, result) => {
            if (error) {
              resolve({ success: false, error: error.message });
            } else {
              resolve({ success: true, imageUrl: result.url });
            }
          });
        }, 500);  // Delay of 500ms between uploads
      })
    );
  
    const results = await Promise.all(uploadPromises);
    res.json(results);
  };
  
  exports.bulkResize = async (req, res) => {
    if (!req.files) {
      return res.status(400).send('No files were uploaded.');
    }
  
    const width = parseInt(req.body.width);
    const height = parseInt(req.body.height);
    const images = req.files.images;
  
    if (!width || !height) {
      return res.status(400).send('Width and height are required.');
    }
  
    const resizePromises = images.map(image => 
      new Promise((resolve) => {
        setTimeout(() => {
          const imageUrl = cloudinary.url(image.name, { width: width, height: height, crop: "fill" });
          resolve({ success: true, resizedImageUrl: imageUrl });
        }, 500);
      })
    );
  
    const results = await Promise.all(resizePromises);
    res.json(results);
  };
  
  exports.bulkAnalyze = async (req, res) => {
    if (!req.files) {
      return res.status(400).send('No files were uploaded.');
    }
  
    const images = req.files.images;
  
    const analyzePromises = images.map(image => 
      new Promise((resolve) => {
        setTimeout(() => {
          cloudinary.uploader.upload(image.tempFilePath, {
            eager: [{width: 200, height: 200, crop: "pad", audio_codec: "none"}],
            eager_async: true,
            eager_notification_url: "https://mysite.example.com/notify_endpoint",
            colors: true, 
            detection: "adv_face"
          }, (error, result) => {
            if (error) {
              resolve({ success: false, error: error.message });
            } else {
              resolve({
                success: true,
                analysis: {
                  dominantColors: result.colors,
                  facesDetected: result.info.detection.adv_face.data
                }
              });
            }
          });
        }, 500);
      })
    );
  
    const results = await Promise.all(analyzePromises);
    res.json(results);
  };
  
  exports.bulkForward = async (req, res) => {
    const endpoint = req.body.endpoint;
    if (!endpoint) {
      return res.status(400).send('Endpoint is required.');
    }
  
    if (!req.files) {
      return res.status(400).send('No files were uploaded.');
    }
  
    const images = req.files.images;
  
    const forwardPromises = images.map(image => 
      new Promise((resolve) => {
        setTimeout(() => {
          axios.post(endpoint, { image: image.data })
            .then(response => {
              resolve({
                success: true,
                message: 'Image forwarded successfully',
                endpointResponse: response.data
              });
            })
            .catch(error => {
              resolve({ success: false, error: error.message });
            });
        }, 500);
      })
    );
  
    const results = await Promise.all(forwardPromises);
    res.json(results);
  };









//    Generative 

exports.dalleUpload = async (req, res) => {
    const prompt = req.body.prompt;
  
    if (!prompt) {
      return res.status(400).send('Prompt is required.');
    }
  
    try {
      const dalleImage = await generateDalleImage(prompt);  // Assume a separate function for DALL·E generation
  
      cloudinary.uploader.upload(dalleImage, (error, result) => {
        if (error) {
          return res.status(500).send('Failed to upload image to Cloudinary');
        }
        res.json({
          success: true,
          imageUrl: result.url
        });
      });
  
    } catch (error) {
      res.status(500).send('Failed to generate image with DALL·E');
    }
  };
  
  exports.bulkDalleUpload = async (req, res) => {
    const prompts = req.body.prompts;  // This should be an array of prompts
  
    if (!prompts || prompts.length === 0) {
      return res.status(400).send('Prompts are required.');
    }
  
    const uploadPromises = prompts.map(prompt => 
      new Promise(async (resolve) => {
        setTimeout(async () => {
          try {
            const dalleImage = await generateDalleImage(prompt);
            cloudinary.uploader.upload(dalleImage, (error, result) => {
              if (error) {
                resolve({ success: false, error: error.message });
              } else {
                resolve({ success: true, imageUrl: result.url });
              }
            });
          } catch (error) {
            resolve({ success: false, error: 'Failed to generate image with DALL·E' });
          }
        }, 500);
      })
    );
  
    const results = await Promise.all(uploadPromises);
    res.json(results);
  };
  
  exports.dalleForward = async (req, res) => {
    const prompt = req.body.prompt;
    const endpoint = req.body.endpoint;
  
    if (!prompt || !endpoint) {
      return res.status(400).send('Prompt and endpoint are required.');
    }
  
    try {
      const dalleImage = await generateDalleImage(prompt);
      axios.post(endpoint, { image: dalleImage })
        .then(response => {
          res.json({
            success: true,
            message: 'Image forwarded successfully',
            endpointResponse: response.data
          });
        })
        .catch(error => {
          res.status(500).send(error.message);
        });
    } catch (error) {
      res.status(500).send('Failed to generate image with DALL·E');
    }
  };

  exports.bulkDalleForward = async (req, res) => {
    const prompts = req.body.prompts;  // This should be an array of prompts
    const endpoint = req.body.endpoint;
  
    if (!prompts || prompts.length === 0 || !endpoint) {
      return res.status(400).send('Prompts and endpoint are required.');
    }
  
    const forwardPromises = prompts.map(prompt => 
      new Promise(async (resolve) => {
        setTimeout(async () => {
          try {
            const dalleImage = await generateDalleImage(prompt);
            axios.post(endpoint, { image: dalleImage })
              .then(response => {
                resolve({
                  success: true,
                  message: 'Image forwarded successfully',
                  endpointResponse: response.data
                });
              })
              .catch(error => {
                resolve({ success: false, error: error.message });
              });
          } catch (error) {
            resolve({ success: false, error: 'Failed to generate image with DALL·E' });
          }
        }, 500);
      })
    );
  
    const results = await Promise.all(forwardPromises);
    res.json(results);
  };
  



