const express = require('express');
const router = express.Router();
const controllers = require("./controllers")
const fileUpload = require('express-fileupload');

const multer = require('multer');
const upload = multer({ limits: { fileSize: 50 * 1024 * 1024 } }); // Limit file size to 50MB
const streamifier = require('streamifier');
const cloudinary = require('cloudinary').v2;


// ====================================================================
//                          Cloudinary Route(s)
// ====================================================================

router.use(fileUpload());

router.post('/upload', controllers.uploadImage);

router.use('/upload/buffer', express.raw({ type: 'multipart/form-data' }));

router.post('/upload/buffer', upload.single('image'), async (req, res) => {
    if (!req.file) {
        return res.status(400).send('No image file uploaded.');
    }

    // Upload to Cloudinary using streamifier
    let cld_upload_stream = cloudinary.uploader.upload_stream(
        { folder: "foo", resource_type: 'image' },
        function(error, result) {
            if (error) {
                console.error('Error uploading to Cloudinary:', error);
                return res.status(500).send('Error uploading image to Cloudinary');
            }
            res.json({ cloudinaryUrl: result.url });
        }
    );

    streamifier.createReadStream(req.file.buffer).pipe(cld_upload_stream);
});

router.post('/uploadfile', controllers.postUploadImageToCloudinary);
router.get('/list', controllers.listImages);
router.delete('/delete/:publicId', controllers.deleteImage);
router.post('/update/:publicId', controllers.updateImage);


// Custom routes

// Custom
router.post('/upload-to-different-cloud', controllers.uploadToDifferentCloud);
router.post('/resize', controllers.resizeImage);
router.post('/forward-to-endpoint', controllers.forwardImageToEndpoint);
router.post('/analyze', controllers.analyzeImage);

//Bulk
router.post('/bulk-upload', controllers.bulkUpload);
router.post('/bulk-resize', controllers.bulkResize);
router.post('/bulk-analyze', controllers.bulkAnalyze);
router.post('/bulk-forward', controllers.bulkForward);


// Generative
router.post('/dalle-upload', controllers.dalleUpload);
router.post('/bulk-dalle-upload', controllers.bulkDalleUpload);
router.post('/dalle-forward', controllers.dalleForward);
router.post('/bulk-dalle-forward', controllers.bulkDalleForward);



// ====================================================================

module.exports = router;
